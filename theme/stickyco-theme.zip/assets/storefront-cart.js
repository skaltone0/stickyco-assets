// ============================================
// STICKYCO STOREFRONT — cart drawer wired to
// Shopify's native Cart AJAX API (/cart.js etc).
// No mock/local cart state — this is real.
// ============================================

var StickyCoCart = (function () {
  var els = {};

  function cacheEls() {
    els.overlay = document.getElementById("cartOverlay");
    els.drawer = document.getElementById("cartDrawer");
    els.items = document.getElementById("cartItems");
    els.foot = document.getElementById("cartFoot");
    els.counts = document.querySelectorAll(".cart-count");
    els.toast = document.getElementById("toast");
  }

  function openCart() {
    els.overlay.classList.add("is-open");
    els.drawer.classList.add("is-open");
    document.body.style.overflow = "hidden";
    refresh();
  }
  function closeCart() {
    els.overlay.classList.remove("is-open");
    els.drawer.classList.remove("is-open");
    document.body.style.overflow = "";
  }

  function showToast(msg) {
    var t = els.toast;
    t.querySelector("span").textContent = msg;
    t.classList.add("is-visible");
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.classList.remove("is-visible"); }, 2600);
  }

  function moneyFmt(cents, currency) {
    return (cents / 100).toLocaleString(undefined, { style: "currency", currency: currency || "IDR" });
  }

  var _lastCount = null;
  function bumpCount() {
    els.counts.forEach(function (el) {
      el.classList.remove("is-bumping");
      void el.offsetWidth;
      el.classList.add("is-bumping");
    });
  }

  function refresh() {
    fetch("/cart.js", { headers: { Accept: "application/json" } })
      .then(function (r) { return r.json(); })
      .then(renderCart)
      .catch(function (e) { console.error("Cart fetch failed", e); });
  }

  function renderCart(cart) {
    var count = cart.item_count;
    els.counts.forEach(function (el) {
      el.textContent = count;
      el.hidden = count === 0;
    });
    if (_lastCount !== null && count > _lastCount) bumpCount();
    _lastCount = count;

    if (!els.items) return;

    if (cart.items.length === 0) {
      els.items.innerHTML =
        '<div class="cart-empty">' +
        '<svg viewBox="0 0 60 60"><use href="#empty-note"/></svg>' +
        '<p class="hand" style="font-size:1.1rem; margin-bottom:0.6rem;">Your cart is empty</p>' +
        '<p style="font-size:0.85rem;">Browse the shop to find something you like.</p>' +
        "</div>";
      els.foot.innerHTML = '<a href="/collections/all" class="btn btn-dark btn-block">Browse stickers</a>';
      return;
    }

    els.items.innerHTML = cart.items
      .map(function (item, idx) {
        var img = item.image ? '<img src="' + item.image + '&width=140" alt="" style="width:100%;height:100%;object-fit:contain;">' : "";
        return (
          '<div class="cart-item">' +
          '<div class="cart-item-art">' + img + "</div>" +
          "<div>" +
          '<p class="cart-item-name">' + item.product_title + "</p>" +
          '<p class="cart-item-opt">' + (item.variant_title || "") + "</p>" +
          '<div class="cart-item-qty">' +
          '<button data-act="dec" data-line="' + (idx + 1) + '" aria-label="Decrease"><svg><use href="#icon-minus"/></svg></button>' +
          "<span>" + item.quantity + "</span>" +
          '<button data-act="inc" data-line="' + (idx + 1) + '" aria-label="Increase"><svg><use href="#icon-plus"/></svg></button>' +
          "</div>" +
          "</div>" +
          "<div>" +
          '<div class="cart-item-price">' + moneyFmt(item.final_line_price, cart.currency) + "</div>" +
          '<button class="cart-item-remove" data-act="remove" data-line="' + (idx + 1) + '">Remove</button>' +
          "</div>" +
          "</div>"
        );
      })
      .join("");

    els.items.querySelectorAll("[data-act]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var line = parseInt(btn.dataset.line, 10);
        var act = btn.dataset.act;
        var item = cart.items[line - 1];
        var newQty = act === "inc" ? item.quantity + 1 : act === "dec" ? item.quantity - 1 : 0;
        changeLine(line, newQty);
      });
    });

    els.foot.innerHTML =
      '<div class="cart-subtotal-row"><span>Subtotal</span><span>' + moneyFmt(cart.total_price, cart.currency) + "</span></div>" +
      '<p class="cart-ship-note">Shipping &amp; taxes calculated at checkout</p>' +
      '<a href="/checkout" class="btn btn-primary btn-block">Checkout</a>';
  }

  function changeLine(line, quantity) {
    fetch("/cart/change.js", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ line: line, quantity: quantity }),
    })
      .then(function (r) { return r.json(); })
      .then(renderCart);
  }

  function initHeroTilt() {
    var area = document.querySelector(".hero-art");
    var note = document.getElementById("heroNoteWrap");
    if (!area || !note) return;
    var prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var isTouchOnly = window.matchMedia("(hover: none)").matches;
    if (prefersReduced || isTouchOnly) return;
    var maxTilt = 10;
    area.addEventListener("mousemove", function (e) {
      var rect = area.getBoundingClientRect();
      var px = (e.clientX - rect.left) / rect.width;
      var py = (e.clientY - rect.top) / rect.height;
      var ry = (px - 0.5) * maxTilt * 2;
      var rx = (0.5 - py) * maxTilt * 2;
      note.style.setProperty("--mx", ry.toFixed(2) + "deg");
      note.style.setProperty("--my", rx.toFixed(2) + "deg");
      note.classList.add("is-tracking");
    });
    area.addEventListener("mouseleave", function () {
      note.classList.remove("is-tracking");
      note.style.removeProperty("--mx");
      note.style.removeProperty("--my");
    });
  }

  function initScrollReveal() {
    var targets = document.querySelectorAll(".container.section, .hero, .page-title-band");
    targets.forEach(function (el) { el.classList.add("reveal"); });
    if (!("IntersectionObserver" in window) || targets.length === 0) {
      targets.forEach(function (el) { el.classList.add("is-revealed"); });
      return;
    }
    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-revealed");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -40px 0px" }
    );
    targets.forEach(function (el) { observer.observe(el); });
    setTimeout(function () {
      targets.forEach(function (el) { el.classList.add("is-revealed"); });
    }, 2500);
  }

  function bindQuickAdd() {
    document.body.addEventListener("click", function (e) {
      var btn = e.target.closest("[data-quickadd]");
      if (!btn) return;
      e.preventDefault();
      var variantId = btn.dataset.quickadd;
      fetch("/cart/add.js", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ items: [{ id: variantId, quantity: 1 }] }),
      })
        .then(function (r) { return r.json(); })
        .then(function () {
          refresh();
          showToast("Added to cart");
        });
    });
  }

  function bindGlobalEvents() {
    document.querySelectorAll("[data-open-cart]").forEach(function (b) { b.addEventListener("click", openCart); });
    document.querySelectorAll("[data-close-cart]").forEach(function (b) { b.addEventListener("click", closeCart); });
    els.overlay.addEventListener("click", function (e) { if (e.target === els.overlay) closeCart(); });
    var mobileBtn = document.getElementById("mobileMenuBtn");
    var mobileSheet = document.getElementById("mobileNavSheet");
    var mobileClose = document.getElementById("mobileNavClose");
    if (mobileBtn) mobileBtn.addEventListener("click", function () { mobileSheet.classList.add("is-open"); });
    if (mobileClose) mobileClose.addEventListener("click", function () { mobileSheet.classList.remove("is-open"); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { closeCart(); if (mobileSheet) mobileSheet.classList.remove("is-open"); }
    });
  }

  function init() {
    cacheEls();
    bindGlobalEvents();
    bindQuickAdd();
    initHeroTilt();
    initScrollReveal();
    refresh();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  return { refresh: refresh, showToast: showToast, openCart: openCart, closeCart: closeCart };
})();

window.StickyCoCart = StickyCoCart;
